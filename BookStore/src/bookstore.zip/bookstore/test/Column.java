package bookstore.test;

public @interface Column {
	String value();
}
