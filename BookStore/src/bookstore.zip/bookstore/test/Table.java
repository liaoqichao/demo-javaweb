package bookstore.test;

public @interface Table {
	String value();
}
