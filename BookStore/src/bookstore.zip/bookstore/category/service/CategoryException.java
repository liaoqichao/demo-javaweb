package bookstore.category.service;

/**
 * �����쳣
 */
public class CategoryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CategoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
