package bookstore.order.service;

public class OrderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
